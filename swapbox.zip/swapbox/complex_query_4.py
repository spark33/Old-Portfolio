
import psycopg2
import sys
import datetime

# Renews the user's subscription with same plan if the subscription has ended
# today should be a tuple of (month, day, year) as accepted by SQL
def renew_subscription(uid,today):
	print("Checking renewal criteria for User #%d...\n" % uid)

	if(packagesLeft(uid) < 0 or past_end_date(uid, today)):
		print("Renewal criteria was met.")
		plan_name = get_plan_name(uid)
		insert_new_subscription(uid, today, plan_name)

	else: print("Renewal criteria was not met. Exiting function.\n")

# Helper Function
# returns number of packages the user has left in their most recent subscription
def packagesLeft(usrId):
    tmp = '''
        SELECT deliveries_used
          FROM Subscriptions
         WHERE user_assigned = %s
      ORDER BY start_date DESC
         LIMIT 1
    '''
    cmd = cur.mogrify(tmp, (usrId,))
    cur.execute(cmd)
    deliveries_used = cur.fetchall()[0][0]

    tmp = '''
        SELECT monthly_quota
          FROM Plans
         WHERE name = (SELECT plan_name
                           FROM Subscriptions
                          WHERE user_assigned = %s
                       ORDER BY start_date DESC
                          LIMIT 1)
    '''
    cmd = cur.mogrify(tmp, (usrId,))
    cur.execute(cmd)
    monthly_quota = cur.fetchall()[0][0]

    return monthly_quota - deliveries_used

# Helper Function
# return plan name of User's latest subscription
def get_plan_name(uid):
	query = '''
		SELECT plan_name
		  FROM Subscriptions
		 WHERE user_assigned = %s
	  ORDER BY start_date DESC
		 LIMIT 1
	'''
	cmd = cur.mogrify(query, [uid])
	cur.execute(cmd)
	plan_name = cur.fetchall()[0][0]
	return plan_name

# Helper Function
# takes in user ID and today's date as a tuple of (month, day, year)
# returns boolean on whether the user's last subscription is past today's date
def past_end_date(uid, today):

	# execute query to check start date of user's last subscription
	check_start_date_query = '''
		SELECT EXTRACT(DAY FROM s.start_date) as Day,
			   EXTRACT(MONTH FROM s.start_date) as Month,
			   EXTRACT(YEAR FROM s.start_date) as Year
		FROM Subscriptions as s
		JOIN Users as u
		  ON u.id = s.user_assigned
		WHERE u.id = %s
		ORDER BY start_date DESC
		LIMIT 1;
	'''
	cmd = cur.mogrify(check_start_date_query, [uid])
	cur.execute(cmd)

	# output is the first row returned by query
	# get day, month and year
	output = cur.fetchall()[0]
	start_day = output[0]
	start_month = output[1]
	start_year = output[2]

	# increment month, since each subscription is monthly
	end_day = start_day
	if(start_month == 12):
		end_month = 1
		end_year = start_year + 1
	else:
		end_month = start_month + 1
		end_year = start_year

	current_month = today[0]
	current_day = today[1]
	current_year = today[2]

	# then check if plan has ended
	return (end_year < current_year or
		   (end_year == current_year and end_month < current_month) or
		   (end_year == current_year and end_month == current_month and end_day < current_day))

# INSERTION INTO DATABASE
# should be called in renew_subscription if criteria for renewal are met
# takes in uid, today as tuple of (month, day, year) and plan_name as string
def insert_new_subscription(uid,today, plan_name):
	today = "%s/%s/%s" % today
	print("Renewing subscription for User #%d.\n" % uid)
	print("It will be a %s plan starting on on %s." % (plan_name, today))
	# format tuple into date item
	insert_query = '''
		INSERT INTO Subscriptions (user_assigned, start_date, deliveries_used, plan_name)
		VALUES(%s, %s, 0, %s)
	'''
	cmd = cur.mogrify(insert_query, [uid, today, plan_name])
	cur.execute(cmd)

if __name__ == '__main__':
	try:
		# default database and user
		db, user = 'project_swapbox', 'isdb16'
		# you may have to adjust the user
		# python a4-socnet-sraja.py a4_socnet postgres
		if len(sys.argv) >= 2:
			db = sys.argv[1]
		if len(sys.argv) >= 3:
			user = sys.argv[2]
		# by assigning to conn and cur here they become
		# global variables.  Hence they are not passed
		# into the various SQL interface functions
		conn = psycopg2.connect(database=db, user=user)
		conn.autocommit = True
		cur = conn.cursor()
		# SAMPLE DATA:
		uid = 2
		# today's date as a tuple of (month, day, year) as accepted by SQL's date type
		# January 19th, 2016
		today = (1, 20, 2016)
		print("Test will run twice to demonstrate when criteria are met and unmet.\n")
		print("Run 1..\n")
		renew_subscription(uid, today)
		print("Run 2..\n")
		renew_subscription(uid, today)
	except psycopg2.Exception as e:
		print("Unable to open connection: %s" % (e,))
