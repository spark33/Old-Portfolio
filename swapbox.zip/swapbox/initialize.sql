\c postgres
DROP DATABASE IF EXISTS project_swapbox;

CREATE database project_swapbox;
\c project_swapbox

\i create.SQL

-- Users.csv
-- Packages.csv
-- Subscriptions.csv
-- Plans.csv
-- Carriers.csv
-- Locations.csv
-- Swapboxes.csv
-- Assignments.csv
-- Package_Statuses.csv

\copy Users(id, name, email, phone, gender, address, join_time)                                          FROM 'sample_data/Users.csv'            csv header
\copy Locations(address, long, lat)                                                                      FROM 'sample_data/Locations.csv'        csv header
\copy Swapboxes(id, capacity, count, address)                                                            FROM 'sample_data/Swapboxes.csv'        csv header
\copy Packages(id, size, weight, from_user, to_user, from_swapbox, to_swapbox, from_address, to_address) FROM 'sample_data/Packages.csv'         csv header
\copy Plans(name, length, cost, monthly_quota)                                                           FROM 'sample_data/Plans.csv'             csv header
\copy Subscriptions(user_assigned, start_date, deliveries_used, plan_name)                               FROM 'sample_data/Subscriptions.csv'     csv header
\copy Carriers(id, name)                                                                                 FROM 'sample_data/Carriers.csv'         csv header
\copy Assignments(tracking_id, package_id, carrier_id)                                                   FROM 'sample_data/Assignments.csv'      csv header
\copy Package_Statuses(package_id, time, last_swapbox, next_swapbox)                       				 FROM 'sample_data/Package_Statuses.csv' csv header
