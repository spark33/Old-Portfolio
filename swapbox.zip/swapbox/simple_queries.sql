\echo "1 - Tracking carrier load:"
	SELECT c.name, count(*)
	  FROM Carriers as c
	       JOIN Assignments as a
	       ON c.id = a.carrier_id
	       JOIN Packages as p
	       ON a.package_id = p.id
	       JOIN Package_Statuses as ps
	       ON p.id = ps.package_id
	 WHERE ps.next_swapbox != -1
	GROUP BY c.id;

\echo "2 - Displaying user 2's favorite swapbox to receive at:"
	SELECT to_swapbox, count(*)
	FROM Packages
	WHERE to_user = 2 and to_swapbox != -1
	GROUP BY to_swapbox
	ORDER BY count(*) DESC
	LIMIT 5;

\echo "3 - Displaying user 2's favorite swapbox to send from:"
	SELECT from_swapbox, count(*)
	FROM Packages
	WHERE from_user = 2 and from_swapbox != -1
	GROUP BY from_swapbox
	ORDER BY count(*) DESC
	LIMIT 5;

\echo "4 - Displaying user 2's packages that are arriving on January 19, 2016."
	SELECT p.id
	FROM Packages as p
	    JOIN Package_Statuses as ps
	    ON p.id = ps.package_id
	WHERE p.to_user = 2 and ps.next_swapbox = -1 and EXTRACT(MONTH FROM ps.time) = 1
	                                               and EXTRACT(DAY FROM ps.time) = 19
	                                               and EXTRACT(YEAR FROM ps.time) = 2016;

\echo "5 - Tracking the last known location of package 10"
	SELECT *
	FROM Package_statuses as ps
	WHERE ps.package_id = 10
	ORDER BY ps.time DESC
	LIMIT 1;

\echo "6 - Displaying most active months"
	SELECT EXTRACT(MONTH FROM ps.time) as "Month", count(*) as "Number of packages"
	FROM Users as u
	   JOIN Packages as p
	   ON u.id = p.from_user
	   JOIN Package_Statuses as ps
	   ON p.id = ps.package_id
	GROUP BY EXTRACT(MONTH FROM ps.time)
	ORDER BY count(*) DESC;
