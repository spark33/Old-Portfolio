-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2016-12-04 21:22:21.334

-- tables
-- Table: Assignments
CREATE TABLE Assignments (
    tracking_id text  NOT NULL,
    package_id int  NOT NULL,
    carrier_id int  NOT NULL,
    CONSTRAINT Assignments_pk PRIMARY KEY (tracking_id)
);

-- Table: Carriers
CREATE TABLE Carriers (
    id int  NOT NULL,
    name text  NOT NULL,
    CONSTRAINT Carriers_pk PRIMARY KEY (id)
);

-- Table: Locations
CREATE TABLE Locations (
    address text  NOT NULL,
    long real  NOT NULL,
    lat real  NOT NULL,
    CONSTRAINT Locations_pk PRIMARY KEY (address)
);

-- Table: Package_Statuses
CREATE TABLE Package_Statuses (
    package_id int  NOT NULL,
    time timestamp  NOT NULL,
    last_swapbox int  NOT NULL,
    next_swapbox int  NOT NULL,
    CONSTRAINT Package_Statuses_pk PRIMARY KEY (package_id,time)
);

-- Table: Packages
CREATE TABLE Packages (
    id int  NOT NULL,
    size text  NOT NULL,
    weight int  NOT NULL,
    from_user int  NOT NULL,
    to_user int  NOT NULL,
    from_swapbox int  NOT NULL,
    to_swapbox int  NOT NULL,
    from_address text  NOT NULL,
    to_address text  NOT NULL,
    CONSTRAINT check_1 CHECK ((from_swapbox=null and (not from_address=null)) or (from_address=null and (not from_swapbox=null))) NOT DEFERRABLE INITIALLY IMMEDIATE,
    CONSTRAINT Packages_pk PRIMARY KEY (id)
);

-- Table: Plans
CREATE TABLE Plans (
    name text  NOT NULL,
    length int  NOT NULL,
    cost money  NOT NULL,
    monthly_quota int  NOT NULL,
    CONSTRAINT Plans_pk PRIMARY KEY (name)
);

-- Table: Subscriptions
CREATE TABLE Subscriptions (
    user_assigned int  NOT NULL,
    start_date date  NOT NULL,
    deliveries_used int  NOT NULL,
    plan_name text  NOT NULL,
    CONSTRAINT Subscriptions_pk PRIMARY KEY (user_assigned,start_date)
);

-- Table: Swapboxes
CREATE TABLE Swapboxes (
    id int  NOT NULL,
    capacity int  NOT NULL,
    count int  NOT NULL,
    address text  NOT NULL,
    CONSTRAINT Swapboxes_pk PRIMARY KEY (id)
);

-- Table: Users
CREATE TABLE Users (
    id int  NOT NULL,
    name text  NOT NULL,
    email text  NOT NULL,
    phone text  NOT NULL,
    gender char(1)  NOT NULL,
    address text  NOT NULL,
    join_time date  NOT NULL,
    CONSTRAINT Users_pk PRIMARY KEY (id)
);

-- foreign keys
-- Reference: Delivery_Carriers (table: Assignments)
ALTER TABLE Assignments ADD CONSTRAINT Delivery_Carriers
    FOREIGN KEY (carrier_id)
    REFERENCES Carriers (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Delivery_Packages (table: Assignments)
ALTER TABLE Assignments ADD CONSTRAINT Delivery_Packages
    FOREIGN KEY (package_id)
    REFERENCES Packages (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: In_Transit_Status_Packages (table: Package_Statuses)
ALTER TABLE Package_Statuses ADD CONSTRAINT In_Transit_Status_Packages
    FOREIGN KEY (package_id)
    REFERENCES Packages (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Locations_Swapboxes (table: Swapboxes)
ALTER TABLE Swapboxes ADD CONSTRAINT Locations_Swapboxes
    FOREIGN KEY (address)
    REFERENCES Locations (address)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: PackageFromSwapbox (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT PackageFromSwapbox
    FOREIGN KEY (from_swapbox)
    REFERENCES Swapboxes (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: PackageToSwapbox (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT PackageToSwapbox
    FOREIGN KEY (to_swapbox)
    REFERENCES Swapboxes (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: PackagesFromLocation (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT PackagesFromLocation
    FOREIGN KEY (from_address)
    REFERENCES Locations (address)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: PackagesToLocation (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT PackagesToLocation
    FOREIGN KEY (to_address)
    REFERENCES Locations (address)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Subscriptions_Plan (table: Subscriptions)
ALTER TABLE Subscriptions ADD CONSTRAINT Subscriptions_Plan
    FOREIGN KEY (plan_name)
    REFERENCES Plans (name)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: Subscriptions_Users (table: Subscriptions)
ALTER TABLE Subscriptions ADD CONSTRAINT Subscriptions_Users
    FOREIGN KEY (user_assigned)
    REFERENCES Users (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: UserReceivesPackage (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT UserReceivesPackage
    FOREIGN KEY (to_user)
    REFERENCES Users (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- Reference: UserShipsPackage (table: Packages)
ALTER TABLE Packages ADD CONSTRAINT UserShipsPackage
    FOREIGN KEY (from_user)
    REFERENCES Users (id)  
    NOT DEFERRABLE 
    INITIALLY IMMEDIATE
;

-- End of file.

