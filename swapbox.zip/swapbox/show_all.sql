-- Users Table
\echo 'Users'
SELECT * FROM Users;

-- Packages Table
\echo 'Packages'
SELECT * FROM Packages;

-- Subscriptions Table
\echo 'Subscriptions'
SELECT * FROM Subscriptions;

-- Plans Table
\echo 'Plans'
SELECT * FROM Plans;

-- Package_Statues Table
\echo 'Package_Statues'
SELECT * FROM Package_Statuses;

-- Swapboxes Table
\echo 'Swapboxes'
SELECT * FROM Swapboxes;

-- Assignments Table
\echo 'Assignments'
SELECT * FROM Assignments;

-- Carriers Table
\echo 'Carriers'
SELECT * FROM Carriers;

-- Locations Table
\echo 'Locations'
SELECT * FROM Locations;
