import psycopg2
import sys
import time
import datetime

# Helper Function to get the number of packages a user's allowed to deliver
def packagesLeft(usrId):
    tmp = '''
        SELECT deliveries_used
          FROM Subscriptions
         WHERE user_assigned = %s
      ORDER BY start_date DESC
         LIMIT 1
    '''
    cmd = cur.mogrify(tmp, (usrId,))
    cur.execute(cmd)
    deliveries_used = cur.fetchall()[0][0]

    tmp = '''
        SELECT monthly_quota
          FROM Plans
         WHERE name = (SELECT plan_name
                           FROM Subscriptions
                          WHERE user_assigned = %s
                       ORDER BY start_date DESC
                          LIMIT 1)
    '''
    cmd = cur.mogrify(tmp, (usrId,))
    cur.execute(cmd)
    monthly_quota = cur.fetchall()[0][0]

    return (deliveries_used, monthly_quota)

# Adds a new package
def add_package(size,weight,from_user,to_user,from_swapbox,to_swapbox,from_address,to_address):
    #First check if the user has exceeded their quota
    (used, quota) = packagesLeft(from_user)
    if (quota-used == 0): print("User "+str(from_user)+" has maxed out their quota of "+str(quota)+" packages.")

    #If they haven't, let's add the package
    else:
        tmpl = '''
            INSERT INTO Packages
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s);
        '''
        #Let's get the count of ids
        cur.execute('''
            SELECT count(*)
            FROM Packages
        ''')
        rows = cur.fetchall()

        #Then use that to get a new id and insert the new person
        #We're doing the length+2 since our packages are 1-indexed
        cmd = cur.mogrify(tmpl, (rows[0][0]+2, size,weight,from_user,to_user,from_swapbox,to_swapbox,from_address,to_address))
        cur.execute(cmd)

        #Now let's increase the number of packages delivered under this subscription
        tmpl = '''
            UPDATE Subscriptions as s1
            SET deliveries_used = %s
            WHERE s1.user_assigned = %s
              and s1.start_date = (SELECT start_date
                                    FROM Subscriptions
                                   WHERE user_assigned = %s
                                ORDER BY start_date DESC
                                   LIMIT 1)
        '''
        cmd = cur.mogrify(tmpl, (used+1,from_user,from_user))
        cur.execute(cmd)

        if (quota > 0):
            print("Added Package. User "+str(from_user)+" has "+str(quota-used-1)+" packages left in their quota.")
        else:
            print("Added Package.")


if __name__ == '__main__':
    try:
        db, user = 'project_swapbox', 'isdb16'
        if len(sys.argv) >= 2:
            db = sys.argv[1]
        if len(sys.argv) >= 3:
            user = sys.argv[2]
        conn = psycopg2.connect(database=db, user=user)
        conn.autocommit = True
        cur = conn.cursor()

        print("This Complex Query adds a package to the database, but first cross-checks to see if the user's maxed out their quota. If they have, it does nothing, otherwise it adds the package and increases the number of deliveries used on their current subscription")

        print("\n== Adding 15 packages from user 6 ==")
        for i in range(15):
            add_package("small", 12, 6, 3, 1,7, "NA", "NA")

    except psycopg2.Exception as e:
        print("Unable to open connection: %s" % (e,))
