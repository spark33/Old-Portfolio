import psycopg2
import sys
import time
import datetime

# Helper Function for track_packages
# Returns the package status as an int - 0 for hasn't left its swapbox, 1 for
# in-transit, and 2 for arrived
def package_status(pID):
    #First let's check and make sure this package exists
    tmp = '''
        SELECT *
          FROM Packages
         WHERE id = %s
    '''
    cmd = cur.mogrify(tmp, (pID,))
    cur.execute(cmd)
    arrivalRows = cur.fetchall()
    if (len(arrivalRows)==0):
        print("Package "+str(pID)+" does not exist.")
    else:
        #Now we can assume the package is in our database
        tmp = '''
            SELECT ps.last_swapbox
              FROM Package_Statuses as ps
             WHERE (ps.package_id = %s ) and ps.next_swapbox = -1
        '''
        cmd = cur.mogrify(tmp, (pID,))
        cur.execute(cmd)
        arrivalRows = cur.fetchall()

        hasArrived = (len(arrivalRows) == 1)
        #If a package has arrived, then it'll have exactly one arrival status
        if (hasArrived):
            return 2
        else:
            #Otherwise it's still in transit. Let's get the last known swapbox.
            tmp = '''
                SELECT ps.last_swapbox
                  FROM Package_Statuses as ps
                 WHERE (ps.package_id = %s )
              ORDER BY ps.time DESC
                 LIMIT 1
            '''
            cmd = cur.mogrify(tmp, (pID,))
            cur.execute(cmd)
            rows = cur.fetchall()
            if (len(rows)>0):
                return 1
            else:
                return 0

# Lists all of a user's packages and their status
def track_packages(usr):
    print("\n")
    # First we check to make sure the user exists
    tmp = '''
        SELECT *
          FROM Users
         WHERE id = %s
    '''
    cmd = cur.mogrify(tmp, (usr,))
    cur.execute(cmd)
    arrivalRows = cur.fetchall()
    if (len(arrivalRows)==0):
        print("User "+str(usr)+" does not exist.")
    else:
        # Now we can assume the User is in our database
        allPackages = '''
            SELECT p.id
              FROM Package_Statuses as ps
         RIGHT JOIN Packages as p
                ON ps.package_id = p.id
             WHERE p.from_user = %s or p.to_user = %s
          GROUP BY p.id
        '''
        cmd = cur.mogrify(allPackages, (usr,usr))
        cur.execute(cmd)
        rows = cur.fetchall()

        # Let's get a list of all the packageIDs associated with this user
        packageIDs = []
        for r in rows:
            packageIDs.append(r[0])

        unDeliveredPackages = []
        inTransitPackages = []
        arrivedPackages = []

        # Then let's categorize them using our helper function package_status
        for x in packageIDs:
            res = package_status(x)
            if (res==0):
                unDeliveredPackages.append(x)
            elif (res==1):
                inTransitPackages.append(x)
            else:
                arrivedPackages.append(x)

        unDel = len(unDeliveredPackages)
        inTrn = len(inTransitPackages)
        arrvd = len(arrivedPackages)
        tot = unDel + inTrn + arrvd

        #Now we'll give the user a summary of their packages
        print("User "+str(usr)+" has a total of "+str(tot)+" packages.")

        # Only print the packages if they have more than one in that category to keep things clean
        if (unDel>0):
            print(str(unDel)+" of them haven't been shipped yet.")
            print(unDeliveredPackages)
        if (inTrn>0):
            print(str(inTrn)+" of them are in transit.")
            print(inTransitPackages)
        if (arrvd>0):
            print(str(arrvd)+" of them have arrived.")
            print(arrivedPackages)

if __name__ == '__main__':
    try:
        db, user = 'project_swapbox', 'isdb16'
        if len(sys.argv) >= 2:
            db = sys.argv[1]
        if len(sys.argv) >= 3:
            user = sys.argv[2]
        conn = psycopg2.connect(database=db, user=user)
        conn.autocommit = True
        cur = conn.cursor()

        print("This Complex Query takes in a userID and prints the status of all their packages, categorized as \"Hasn't Left the original Swapbox\", \"In-Transit\", and \"Arrived\"")

        print("\n== Tracing packages for first 10 users ==")
        for i in range(10):
            track_packages(i+1)

    except psycopg2.Exception as e:
        print("Unable to open connection: %s" % (e,))
