import psycopg2
import sys
import time
import datetime

def print_rows(rows):
    for row in rows:
        print(row)


#Assigns a package to a carrier by name
def assign(pID, carrierName):
    # First check if the carrier already exists in our database
    tmp = '''
        SELECT *
        FROM Carriers
        WHERE name = %s
        '''
    cmd = cur.mogrify(tmp, (carrierName,))
    cur.execute(cmd)
    rows = cur.fetchall()
    exists = len(rows) > 0
    # If the carrier doesn't exist, we need to add them to our database first.
    if (not exists):
        tmp = '''
            INSERT INTO Carriers
            VALUES((SELECT count(*)+1
                      FROM Carriers), %s)
            '''
        cmd = cur.mogrify(tmp, (carrierName,))
        cur.execute(cmd)

    # Now the carrier is in our table for sure so let's make an association entity
    # to link them together

    tmp = '''
        INSERT INTO Assignments
        VALUES((SELECT count(*)+1
                  FROM Assignments),
                  %s,
               (SELECT id
                  FROM Carriers
                  WHERE name = %s
                  LIMIT 1))
        '''
    cmd = cur.mogrify(tmp, (pID, carrierName))
    cur.execute(cmd)

if __name__ == '__main__':
    try:
        db, user = 'project_swapbox', 'isdb16'
        if len(sys.argv) >= 2:
            db = sys.argv[1]
        if len(sys.argv) >= 3:
            user = sys.argv[2]
        conn = psycopg2.connect(database=db, user=user)
        conn.autocommit = True
        cur = conn.cursor()

        print("This Complex Query assigns packages to carriers by name, creating a new carrier entity if the one we're attempting to assign to doesn't exist.")
        print("The original tables looked like this:")

        # Let's look at the table to begin with
        print("\nOrig Assignments Table:")
        tmp = '''
            SELECT *
            FROM Assignments
            '''
        cur.execute(tmp)
        print_rows(cur.fetchall())

        print("\nOrig Carriers Table:")
        tmp = '''
            SELECT *
            FROM Carriers
            '''
        cur.execute(tmp)
        print_rows(cur.fetchall())

        print("\nAssigning packages 10,11,12,13, and 14 to various carriers - both in and not in the database..")
        # Let's assign some packages to carriers, both in and not in the database
        assign(10, "LupeFiasco Ltd.") # New Carrier
        assign(11, "FedEx")
        assign(12, "LupeFiasco Ltd.")
        assign(13, "UPS")
        assign(14, "ThirdPartyDeliveries Inc.") # New Carrier
        print("..Packages assigned, printing new tables.")
        # And to show that it worked, let's print the assignment and carrier tables
        print("\nNew Assignments Table:")
        tmp = '''
            SELECT *
            FROM Assignments
            '''
        cur.execute(tmp)
        print_rows(cur.fetchall())

        print("\nNew Carriers Table:")
        tmp = '''
            SELECT *
            FROM Carriers
            '''
        cur.execute(tmp)
        print_rows(cur.fetchall())

    except psycopg2.Exception as e:
        print("Unable to open connection: %s" % (e,))
